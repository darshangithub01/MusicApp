import json
import boto3
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('login')

def lambda_handler(event, context):
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
    }

    if event.get("httpMethod") == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps("Preflight OK")
        }

    if event.get("httpMethod") != "POST":
        return {
            "statusCode": 405,
            "headers": headers,
            "body": json.dumps({ "error": "Method not allowed" })
        }

    try:
        body = json.loads(event.get("body", "{}"))
        email = body.get("email")
        password = body.get("password")

        if not email or not password:
            return {
                "statusCode": 400,
                "headers": headers,
                "body": json.dumps({ "error": "Missing credentials" })
            }

        response = table.query(
            KeyConditionExpression=Key("email").eq(email)
        )

        print("Query result:", response)

        if response["Count"] == 0:
            return {
                "statusCode": 200,
                "headers": headers,
                "body": json.dumps({ "status": "not_found" })
            }

        
        user_item = response["Items"][0]
        if user_item["password"] != password:
            return {
                "statusCode": 200,
                "headers": headers,
                "body": json.dumps({ "status": "invalid" })
            }

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({
                "status": "success",
                "user_name": user_item["user_name"]
            })
        }

    except Exception as e:
        print("ERROR:", str(e))
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({ "error": "Something went wrong" })
        }
