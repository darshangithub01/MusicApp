import json
import boto3
from boto3.dynamodb.conditions import Attr
from decimal import Decimal
 
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('music')
 
def convert_decimal(obj):
    if isinstance(obj, list):
        return [convert_decimal(i) for i in obj]
    elif isinstance(obj, dict):
        return {k: convert_decimal(v) for k, v in obj.items()}
    elif isinstance(obj, Decimal):
        return int(obj) if obj % 1 == 0 else float(obj)
    else:
        return obj
 
def lambda_handler(event, context):
    print("Received event:", event)
 
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
    }
 
    if event.get("httpMethod") == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps("CORS preflight OK")
        }
 
    if event.get("httpMethod") != "POST":
        return {
            "statusCode": 405,
            "headers": headers,
            "body": json.dumps({"error": "Method not allowed"})
        }
 
    try:
        body = json.loads(event.get("body", "{}"))
        filters = []
 
        if "title" in body and body["title"]:
            filters.append(Attr("title").contains(body["title"]))
        if "artist" in body and body["artist"]:
            filters.append(Attr("artist").contains(body["artist"]))
        if "album" in body and body["album"]:
            filters.append(Attr("album").contains(body["album"]))
 
        
        if "year" in body and body["year"]:
            try:
                year_int = int(body["year"])
                filters.append(Attr("year").eq(year_int))
            except ValueError:
                print("Invalid year format, ignoring.")
 
        if filters:
            filter_expr = filters[0]
            for f in filters[1:]:
                filter_expr &= f
            response = table.scan(FilterExpression=filter_expr)
        else:
            response = table.scan()
 
        items = convert_decimal(response.get("Items", []))
 
        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps(items)
        }
 
    except Exception as e:
        print("Error:", str(e))
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": "Something went wrong"})
        }
 
 