import json
import boto3
 
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('subscriptions')
 
def lambda_handler(event, context):
    print("Received event:", event)
 
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
    }
 
    method = event.get("httpMethod", "")
 
    if method == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps("CORS preflight OK")
        }
 
    if method == "POST":
        try:
            body = json.loads(event.get("body", "{}"))
            email = body.get("email")
            title = body.get("title")
 
            if not email or not title:
                return {
                    "statusCode": 400,
                    "headers": headers,
                    "body": json.dumps({"error": "Missing 'email' or 'title'"})
                }
 
            table.delete_item(Key={"email": email, "title": title})
 
            return {
                "statusCode": 200,
                "headers": headers,
                "body": json.dumps({"message": f"Subscription removed: {title}"})
            }
 
        except Exception as e:
            print("Error:", str(e))
            return {
                "statusCode": 500,
                "headers": headers,
                "body": json.dumps({"error": "Server error"})
            }
 
    return {
        "statusCode": 405,
        "headers": headers,
        "body": json.dumps({"error": "Method not allowed"})
    }
 