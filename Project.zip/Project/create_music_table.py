import boto3

# Initializing DynamoDB
dynamodb = boto3.resource('dynamodb', region_name="us-east-1") 

# This creates the music table " music"
table_name = "music"

table = dynamodb.create_table(
    TableName=table_name,
    KeySchema=[
        {'AttributeName': 'title', 'KeyType': 'HASH'},  # This is the partition key
        {'AttributeName': 'version', 'KeyType': 'RANGE'}  # This is for sort key
    ],
    AttributeDefinitions=[
        {'AttributeName': 'title', 'AttributeType': 'S'},
        {'AttributeName': 'version', 'AttributeType': 'S'}
    ],
    ProvisionedThroughput={'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}
)

print(f"Creating table {table_name}...")
table.wait_until_exists()
print(f"Table {table_name} created successfully!")
