import boto3
import json

# Here iam intializing the DynamoDB table
dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
table = dynamodb.Table("music")

# This is to Load the json file
json_file = "2025a1.json"
with open(json_file, "r") as f:
    data = json.load(f)

# This is to ensure JSON format is correct
if isinstance(data, list):
    data = {"music": data}

# Here we are insert/update item in DynamoDB
def insert_or_update_item(item):
    title = item.get("title", "").strip()
    version = item.get("version", "original").strip()
    artist = item.get("artist", "Unknown Artist").strip()  
    album = item.get("album", "Unknown Album").strip()
    image_url = item.get("image_url", "Unknown URL").strip()
    year = item.get("year", "Unknown Year")

    if not title or not version:
        print(f" Skipping song with missing title or version: {item}")
        return

    print(f"Processing: {title} by {artist} (Version: {version})")

    try:
        # Inserting/Updating 
        table.put_item(
            Item={
                "title": title,
                "version": version,
                "artist": artist,  
                "album": album,
                "image_url": image_url,
                "year": year
            }
        )
        print(f"Inserted/Updated: {title} by {artist} ({version})")

    except Exception as e:
        print(f"Error inserting {title} ({version}): {str(e)}")

# This is to insert Batch
batch_size = 25
print(f"Uploading {len(data['music'])} songs to DynamoDB...")

for i in range(0, len(data["music"]), batch_size):
    batch = data["music"][i : i + batch_size]
    for song in batch:
        insert_or_update_item(song)

print("Data upload completed!")
