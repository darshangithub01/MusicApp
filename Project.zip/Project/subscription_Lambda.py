import json
import boto3
from boto3.dynamodb.conditions import Key
from decimal import Decimal
 
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('subscriptions') 
 
def convert_decimal(obj):
    if isinstance(obj, list):
        return [convert_decimal(i) for i in obj]
    elif isinstance(obj, dict):
        return {k: convert_decimal(v) for k, v in obj.items()}
    elif isinstance(obj, Decimal):
        return int(obj) if obj % 1 == 0 else float(obj)
    else:
        return obj
 
def lambda_handler(event, context):
    print("Received event:", event)
 
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
    }
 
    method = event.get("httpMethod")
 
    if method == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps("CORS preflight passed")
        }
 
    try:
        if method == "GET":
            email = event.get("queryStringParameters", {}).get("email", "")
            if not email:
                raise ValueError("Missing email")
 
            response = table.query(
                KeyConditionExpression=Key("email").eq(email)
            )
            items = convert_decimal(response.get("Items", []))
 
            return {
                "statusCode": 200,
                "headers": headers,
                "body": json.dumps(items)
            }
 
        elif method == "POST":
            body = json.loads(event.get("body", "{}"))
 
            required_fields = ["email", "title", "artist", "album", "year", "image_url"]
            for field in required_fields:
                if field not in body or not body[field]:
                    raise ValueError(f"Missing field: {field}")
 
            table.put_item(Item={
                "email": body["email"],
                "title": body["title"],
                "artist": body["artist"],
                "album": body["album"],
                "year": body["year"],
                "image_url": body["image_url"]
            })
 
            return {
                "statusCode": 200,
                "headers": headers,
                "body": json.dumps({"message": "Subscription added"})
            }
 
        else:
            return {
                "statusCode": 405,
                "headers": headers,
                "body": json.dumps({"error": "Method not allowed"})
            }
 
    except Exception as e:
        print("Error:", str(e))
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": str(e)})
        }
 