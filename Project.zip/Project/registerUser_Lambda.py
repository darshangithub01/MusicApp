import json
import boto3
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('login') 
def lambda_handler(event, context):
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
    }

    print("=== Incoming Event ===")
    print(json.dumps(event))  

    
    if event.get("httpMethod") == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps("Preflight OK")
        }

    
    if event.get("httpMethod") != "POST":
        return {
            "statusCode": 405,
            "headers": headers,
            "body": json.dumps({ "error": "Method not allowed" })
        }

    try:
        # Parse body
        body_raw = event.get("body", "{}")
        print("Raw body string:", body_raw)
        body = json.loads(body_raw)

        email = body.get("email")
        user_name = body.get("username")
        password = body.get("password")

        print(f"Parsed email: {email}, username: {user_name}, password: {password}")

        # Validate required fields
        if not email or not password or not user_name:
            print("Missing required fields")
            return {
                "statusCode": 400,
                "headers": headers,
                "body": json.dumps({ "error": "Missing fields" })
            }

        
        response = table.query(
            KeyConditionExpression=Key("email").eq(email)
        )

        print("DynamoDB query response:", response)

        if response["Count"] > 0:
            print("User already exists with this email")
            return {
                "statusCode": 200,
                "headers": headers,
                "body": json.dumps({ "status": "exists" })
            }

        
        table.put_item(Item={
            "email": email,
            "user_name": user_name,
            "password": password
        })

        print("User successfully registered")
        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({ "status": "success" })
        }

    except Exception as e:
        print("ERROR:", str(e))
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({ "error": "Something went wrong" })
        }
