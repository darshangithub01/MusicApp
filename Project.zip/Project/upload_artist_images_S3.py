import boto3
import requests
import json
import os

# JSON file 
json_file = "2025a1.json"  #  Using the original filename
bucket_name = "4067322-images"  #  Your actual S3 bucket name
image_folder = "artist_images"  #  Name of our local folder

# Create a directory to store downloaded images
if not os.path.exists(image_folder):
    os.makedirs(image_folder)

# Initialize AWS S3 client
s3 = boto3.client("s3")

def download_image(image_url, filename):
    """Download an image from a URL and save it locally."""
    try:
        response = requests.get(image_url, stream=True, timeout=10)
        response.raise_for_status()  # Raise an error for bad status codes

        file_path = os.path.join(image_folder, filename)
        with open(file_path, "wb") as img_file:
            for chunk in response.iter_content(1024):
                img_file.write(chunk)
        print(f"Downloaded: {filename}")
        return file_path
    except requests.exceptions.RequestException as e:
        print(f"❌ Error downloading {image_url}: {e}")
        return None

def upload_to_s3(file_path, s3_filename):
    """Upload an image to the specified S3 bucket."""
    try:
        s3.upload_file(file_path, bucket_name, s3_filename)
        print(f"Uploaded to S3: {s3_filename}")
    except Exception as e:
        print(f" Error uploading {file_path} to S3: {e}")

# Read the JSON file and process each image URL
try:
    with open(json_file, "r", encoding="utf-8") as file:
        data = json.load(file)
    
    for item in data["music"]:  # Make sure to loop through "music" key
        if "image_url" in item and item["image_url"]:
            image_url = item["image_url"]
            
            # Generate a unique filename based on artist + title
            artist_name = item["artist"].replace(" ", "_").lower()
            song_title = item["title"].replace(" ", "_").lower()
            filename = f"{artist_name}_{song_title}.jpg"

            # Download image
            image_path = download_image(image_url, filename)

            # Upload to S3 if download was successful
            if image_path:
                upload_to_s3(image_path, f"artists/{filename}")

except Exception as e:
    print(f"Error processing JSON file: {e}")

print("Image upload process completed!")
